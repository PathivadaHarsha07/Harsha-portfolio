export default function Experience() {
  const responsibilities = [
    "Hands-on experience in full-stack development using Java, PHP, JavaScript, React.js, HTML, CSS, and Bootstrap",
    "Built responsive web interfaces and dynamic UIs using React.js and Bootstrap for modern web applications",
    "Developed backend services using Java (Servlets, JSP, Spring Boot, REST APIs) and PHP, following MVC architecture",
    "Worked with MySQL, JDBC, and Hibernate for efficient data storage and retrieval",
    "Proficient with tools like Eclipse, VS Code, Git, and GitHub for development and version control",
    "Collaborated with cross-functional teams to deliver high-quality software solutions",
    "Participated in code reviews and maintained coding standards",
    "Implemented responsive design principles for optimal user experience across devices"
  ]

  const achievements = [
    "Successfully delivered 4+ major projects including real-time monitoring systems",
    "Improved application performance by implementing efficient database queries",
    "Contributed to the development of scalable microservices architecture",
    "Mentored junior developers and shared knowledge through code reviews"
  ]

  return (
    <>
      <header className="page-header">
        <div className="container">
          <h1>Work Experience</h1>
          <p>My professional journey and accomplishments in software development</p>
        </div>
      </header>

      <section className="section">
        <div className="container">
          <div className="card experience-card max-w-4xl mx-auto">
            <div className="experience-header">
              <div>
                <h3 className="experience-title">Junior Software Engineer (Full Stack Developer)</h3>
                <p className="experience-company">IScientific Techsolutions Labs Pvt.Ltd</p>
                <p className="experience-duration">May 2023 - Present</p>
              </div>
              <span className="badge badge-success">Current Position</span>
            </div>

            <div style={{ marginBottom: '2rem' }}>
              <h4 style={{ fontSize: '1.25rem', fontWeight: '600', marginBottom: '1rem', color: '#1e293b' }}>
                Key Responsibilities
              </h4>
              <ul className="experience-list">
                {responsibilities.map((responsibility, index) => (
                  <li key={index}>{responsibility}</li>
                ))}
              </ul>
            </div>

            <div style={{ marginBottom: '2rem' }}>
              <h4 style={{ fontSize: '1.25rem', fontWeight: '600', marginBottom: '1rem', color: '#1e293b' }}>
                Key Achievements
              </h4>
              <ul className="experience-list">
                {achievements.map((achievement, index) => (
                  <li key={index}>{achievement}</li>
                ))}
              </ul>
            </div>

            <div>
              <h4 style={{ fontSize: '1.25rem', fontWeight: '600', marginBottom: '1rem', color: '#1e293b' }}>
                Technologies Used
              </h4>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                {[
                  "Java", "Spring Boot", "React.js", "PHP", "MySQL", "HTML", "CSS", "Bootstrap", 
                  "JavaScript", "Git", "GitHub", "REST APIs", "Microservices"
                ].map((tech) => (
                  <span key={tech} className="badge badge-secondary">
                    {tech}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Career Timeline */}
          <div className="mt-8">
            <div className="section-title">
              <h2>Career Timeline</h2>
            </div>
            <div style={{ position: 'relative', maxWidth: '48rem', margin: '0 auto' }}>
              <div style={{ 
                position: 'absolute', 
                left: '1rem', 
                top: 0, 
                bottom: 0, 
                width: '2px', 
                backgroundColor: '#cbd5e1' 
              }}></div>

              <div style={{ position: 'relative', display: 'flex', alignItems: 'center', marginBottom: '2rem' }}>
                <div style={{ 
                  width: '2rem', 
                  height: '2rem', 
                  backgroundColor: '#2563eb', 
                  borderRadius: '50%', 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center', 
                  color: 'white', 
                  fontWeight: '700', 
                  fontSize: '0.875rem' 
                }}>
                  1
                </div>
                <div style={{ marginLeft: '1.5rem' }}>
                  <h3 style={{ fontWeight: '600', fontSize: '1.125rem' }}>Started as Junior Software Engineer</h3>
                  <p style={{ color: '#64748b' }}>May 2023 - Joined IScientific Techsolutions Labs</p>
                </div>
              </div>

              <div style={{ position: 'relative', display: 'flex', alignItems: 'center', marginBottom: '2rem' }}>
                <div style={{ 
                  width: '2rem', 
                  height: '2rem', 
                  backgroundColor: '#22c55e', 
                  borderRadius: '50%', 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center', 
                  color: 'white', 
                  fontWeight: '700', 
                  fontSize: '0.875rem' 
                }}>
                  2
                </div>
                <div style={{ marginLeft: '1.5rem' }}>
                  <h3 style={{ fontWeight: '600', fontSize: '1.125rem' }}>Full Stack Development Focus</h3>
                  <p style={{ color: '#64748b' }}>2023 - Specialized in Java and React.js development</p>
                </div>
              </div>

              <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
                <div style={{ 
                  width: '2rem', 
                  height: '2rem', 
                  backgroundColor: '#a855f7', 
                  borderRadius: '50%', 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center', 
                  color: 'white', 
                  fontWeight: '700', 
                  fontSize: '0.875rem' 
                }}>
                  3
                </div>
                <div style={{ marginLeft: '1.5rem' }}>
                  <h3 style={{ fontWeight: '600', fontSize: '1.125rem' }}>Project Leadership</h3>
                  <p style={{ color: '#64748b' }}>2024 - Leading multiple high-impact projects</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
