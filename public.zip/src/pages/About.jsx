export default function About() {
  return (
    <>
      <header className="page-header">
        <div className="container">
          <h1>About Me</h1>
          <p>Learn more about my background and what drives me</p>
        </div>
      </header>

      <section className="section">
        <div className="container">
          <div className="about-content">
            {/* Left Column - Main Content */}
            <div className="about-text">
              <h3>Full Stack Developer</h3>
              <p>
                I'm a passionate Full Stack Java Developer with 2+ years of hands-on experience in building scalable web
                applications. Currently working as a Junior Software Engineer at IScientific Techsolutions Labs Pvt.Ltd,
                where I develop end-to-end solutions using modern technologies.
              </p>
              <p>
                My expertise spans across frontend technologies like React.js and backend development with Java, Spring
                Boot, and microservices architecture. I'm passionate about creating efficient, user-friendly
                applications that solve real-world problems.
              </p>
              <p>
                I believe in continuous learning and staying updated with the latest technologies. My goal is to
                contribute to innovative projects that make a positive impact while growing as a professional developer.
              </p>
              
              <div className="about-stats">
                <div className="about-stat">
                  <div className="about-stat-number">2+</div>
                  <div className="about-stat-label">Years Experience</div>
                </div>
                <div className="about-stat">
                  <div className="about-stat-number">10+</div>
                  <div className="about-stat-label">Projects Completed</div>
                </div>
              </div>
            </div>

            {/* Right Column - Cards */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              {/* Current Role Card */}
              <div className="card">
                <div className="flex items-center mb-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="#2563eb"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    style={{ marginRight: '0.75rem', flexShrink: 0 }}
                  >
                    <path d="M22 20V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2h16a2 2 0 0 0 2-2Z" />
                    <path d="M14 13v4" />
                    <path d="M10 13v4" />
                  </svg>
                  <h4 style={{ 
                    fontWeight: '600', 
                    fontSize: '1.25rem', 
                    color: '#1e293b', 
                    margin: 0,
                    lineHeight: '1.2'
                  }}>
                    Current Role
                  </h4>
                </div>
                <div style={{ 
                  marginBottom: '0.75rem', 
                  fontWeight: '600', 
                  color: '#1e293b',
                  fontSize: '1.1rem'
                }}>
                  Junior Software Engineer
                </div>
                <div style={{ 
                  marginBottom: '0.75rem', 
                  color: '#475569',
                  lineHeight: '1.4'
                }}>
                  IScientific Techsolutions Labs Pvt.Ltd
                </div>
                <div style={{ 
                  fontSize: '0.875rem', 
                  color: '#64748b',
                  fontWeight: '500'
                }}>
                  May 2023 - Present
                </div>
              </div>

              {/* Education Card */}
              <div className="card">
                <div className="flex items-center mb-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="#2563eb"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    style={{ marginRight: '0.75rem', flexShrink: 0 }}
                  >
                    <path d="M22 10v6M2 10l10-5 10 5-10 5z" />
                    <path d="M6 12v5c3 3 9 3 12 0v-5" />
                  </svg>
                  <h4 style={{ 
                    fontWeight: '600', 
                    fontSize: '1.25rem', 
                    color: '#1e293b', 
                    margin: 0,
                    lineHeight: '1.2'
                  }}>
                    Education
                  </h4>
                </div>
                <div style={{ 
                  marginBottom: '0.75rem', 
                  fontWeight: '600', 
                  color: '#1e293b',
                  fontSize: '1.1rem'
                }}>
                  B.Tech in Electronics & Communication
                </div>
                <div style={{ 
                  marginBottom: '0.75rem', 
                  color: '#475569',
                  lineHeight: '1.4'
                }}>
                  GMR Institute of Technology
                </div>
                <div style={{ 
                  fontSize: '0.875rem', 
                  color: '#64748b',
                  fontWeight: '500'
                }}>
                  CGPA: 7.84 (2019-2023)
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}