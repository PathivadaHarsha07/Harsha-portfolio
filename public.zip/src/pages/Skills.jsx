export default function Skills() {
  const skills = {
    "Programming Languages": {
      skills: ["Java", "PHP", "JavaScript"],
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="20"
          height="20"
          viewBox="0 0 24 24"
          fill="none"
          stroke="#2563eb"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="m18 16-4-4 4-4" />
          <path d="m6 8 4 4-4 4" />
        </svg>
      )
    },
    "Frontend Technologies": {
      skills: ["HTML", "CSS", "Bootstrap", "React.js"],
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="20"
          height="20"
          viewBox="0 0 24 24"
          fill="none"
          stroke="#22c55e"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="12" cy="12" r="10" />
          <path d="M2 12h20" />
          <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
        </svg>
      )
    },
    "Backend Technologies": {
      skills: ["Servlets", "JSP", "Spring Boot", "Microservices", "REST APIs"],
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="20"
          height="20"
          viewBox="0 0 24 24"
          fill="none"
          stroke="#a855f7"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <rect x="2" y="2" width="20" height="8" rx="2" ry="2" />
          <rect x="2" y="14" width="20" height="8" rx="2" ry="2" />
          <line x1="6" y1="6" x2="6.01" y2="6" />
          <line x1="6" y1="18" x2="6.01" y2="18" />
        </svg>
      )
    },
    "Database & ORM": {
      skills: ["MySQL", "JDBC", "Hibernate"],
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="20"
          height="20"
          viewBox="0 0 24 24"
          fill="none"
          stroke="#f97316"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <ellipse cx="12" cy="5" rx="9" ry="3" />
          <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
          <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
        </svg>
      )
    },
    "Architecture & Design": {
      skills: ["MVC Architecture", "RESTful Services"],
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="20"
          height="20"
          viewBox="0 0 24 24"
          fill="none"
          stroke="#ef4444"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M20 7h-9" />
          <path d="M14 17H5" />
          <circle cx="17" cy="17" r="3" />
          <circle cx="7" cy="7" r="3" />
        </svg>
      )
    },
    "Tools & Development": {
      skills: ["Eclipse", "VS Code", "Git", "GitHub"],
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="20"
          height="20"
          viewBox="0 0 24 24"
          fill="none"
          stroke="#6366f1"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M12 8a2 2 0 1 0 4 0 2 2 0 1 0-4 0" />
          <path d="M12 2a6 6 0 0 1 6 6c0 1.5-1 6-6 10-5-4-6-8.5-6-10a6 6 0 0 1 6-6Z" />
        </svg>
      )
    }
  }

  return (
    <>
      <header className="page-header">
        <div className="container">
          <h1>Technical Skills</h1>
          <p>My technical expertise and proficiencies across different technologies</p>
        </div>
      </header>

      <section className="section">
        <div className="container">
          <div className="grid grid-3">
            {Object.entries(skills).map(([category, data]) => (
              <div key={category} className="card">
                <div className="skill-card-title">
                  {data.icon}
                  {category}
                </div>
                <div className="skill-card-content">
                  {data.skills.map((skill) => (
                    <span key={skill} className="badge badge-primary">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Additional Skills Section */}
          <div className="mt-8">
            <div className="section-title">
              <h2>Additional Competencies</h2>
            </div>
            <div className="grid grid-4">
              <div className="card text-center">
                <h3 style={{ fontSize: '1.125rem', fontWeight: '600', marginBottom: '0.75rem' }}>Problem Solving</h3>
                <p style={{ color: '#64748b' }}>Analytical thinking and debugging</p>
              </div>
              <div className="card text-center">
                <h3 style={{ fontSize: '1.125rem', fontWeight: '600', marginBottom: '0.75rem' }}>Team Collaboration</h3>
                <p style={{ color: '#64748b' }}>Agile methodologies and teamwork</p>
              </div>
              <div className="card text-center">
                <h3 style={{ fontSize: '1.125rem', fontWeight: '600', marginBottom: '0.75rem' }}>API Development</h3>
                <p style={{ color: '#64748b' }}>RESTful services and integration</p>
              </div>
              <div className="card text-center">
                <h3 style={{ fontSize: '1.125rem', fontWeight: '600', marginBottom: '0.75rem' }}>Version Control</h3>
                <p style={{ color: '#64748b' }}>Git workflows and collaboration</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
