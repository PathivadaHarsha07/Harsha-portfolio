export default function Education() {
  const certifications = [
    {
      title: "Power BI Workshop Certification",
      provider: "Professional Workshop",
      description: "Successfully completed a comprehensive workshop focused on Power BI, covering data visualization, dashboard creation, and data analysis techniques.",
      skills: ["Data Visualization", "Dashboard Creation", "Data Analysis", "Business Intelligence"],
      date: "2023"
    },
    {
      title: "Introduction to Python",
      provider: "Udemy",
      description: "Completed an online course covering Python fundamentals, including basic syntax, data structures, and introductory programming concepts.",
      skills: ["Python Programming", "Data Structures", "Programming Fundamentals", "Problem Solving"],
      date: "2023"
    }
  ]

  const academicAchievements = [
    "Maintained consistent academic performance throughout the program",
    "Completed major project on embedded systems and IoT applications",
    "Participated in technical workshops and seminars",
    "Developed strong foundation in electronics and communication principles"
  ]

  const relevantCoursework = [
    "Data Structures and Algorithms",
    "Database Management Systems",
    "Computer Networks",
    "Software Engineering",
    "Web Technologies",
    "Object-Oriented Programming",
    "Microprocessors and Microcontrollers",
    "Digital Signal Processing"
  ]

  return (
    <>
      <header className="page-header">
        <div className="container">
          <h1>Education & Certifications</h1>
          <p>My academic background and professional certifications that have shaped my technical expertise</p>
        </div>
      </header>

      <section className="section">
        <div className="container">
          {/* Education Section */}
          <div style={{ marginBottom: '4rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: '2rem' }}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#2563eb"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                style={{ marginRight: '0.75rem' }}
              >
                <path d="M22 10v6M2 10l10-5 10 5-10 5z" />
                <path d="M6 12v5c3 3 9 3 12 0v-5" />
              </svg>
              <h2 style={{ fontSize: '1.5rem', fontWeight: '700', color: '#1e293b' }}>Academic Education</h2>
            </div>

            <div className="card" style={{ borderLeft: '4px solid #2563eb' }}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginBottom: '1.5rem' }}>
                <div>
                  <h3 style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>Bachelor of Technology (B.Tech)</h3>
                  <p style={{ fontSize: '1.25rem', color: '#2563eb', fontWeight: '500', marginBottom: '0.5rem' }}>
                    Electronics & Communication Engineering
                  </p>
                  <p style={{ fontSize: '1.125rem', color: '#64748b', marginBottom: '0.5rem' }}>
                    GMR Institute of Technology
                  </p>
                  <p style={{ color: '#64748b', display: 'flex', alignItems: 'center' }}>
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      style={{ marginRight: '0.5rem' }}
                    >
                      <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
                      <line x1="16" y1="2" x2="16" y2="6" />
                      <line x1="8" y1="2" x2="8" y2="6" />
                      <line x1="3" y1="10" x2="21" y2="10" />
                    </svg>
                    2019 - 2023 • Rajam, Andhra Pradesh
                  </p>
                </div>
                <span className="badge badge-primary" style={{ width: 'fit-content', fontSize: '1rem', padding: '0.5rem 1rem' }}>
                  CGPA: 7.84
                </span>
              </div>

              <div style={{ marginBottom: '1.5rem' }}>
                <h4 style={{ fontSize: '1.125rem', fontWeight: '600', marginBottom: '0.75rem', color: '#1e293b' }}>
                  Academic Achievements
                </h4>
                <ul style={{ listStyle: 'none', padding: 0 }}>
                  {academicAchievements.map((achievement, index) => (
                    <li key={index} style={{ display: 'flex', alignItems: 'flex-start', marginBottom: '0.5rem' }}>
                      <div style={{ 
                        width: '8px', 
                        height: '8px', 
                        backgroundColor: '#2563eb', 
                        borderRadius: '50%', 
                        marginRight: '0.75rem', 
                        marginTop: '0.5rem',
                        flexShrink: 0
                      }}></div>
                      <span style={{ color: '#64748b' }}>{achievement}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 style={{ fontSize: '1.125rem', fontWeight: '600', marginBottom: '0.75rem', color: '#1e293b' }}>
                  Relevant Coursework
                </h4>
                <div className="grid grid-4">
                  {relevantCoursework.map((course) => (
                    <span key={course} className="badge badge-secondary" style={{ justifyContent: 'center', padding: '0.5rem' }}>
                      {course}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Certifications Section */}
          <div style={{ marginBottom: '4rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: '2rem' }}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#22c55e"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                style={{ marginRight: '0.75rem' }}
              >
                <path d="M12 8a2 2 0 1 0 4 0 2 2 0 1 0-4 0" />
                <path d="M12 2a6 6 0 0 1 6 6c0 1.5-1 6-6 10-5-4-6-8.5-6-10a6 6 0 0 1 6-6Z" />
              </svg>
              <h2 style={{ fontSize: '1.5rem', fontWeight: '700', color: '#1e293b' }}>Professional Certifications</h2>
            </div>

            <div className="grid grid-2">
              {certifications.map((cert, index) => (
                <div key={index} className="card">
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1rem' }}>
                    <div>
                      <h3 style={{ fontSize: '1.25rem', marginBottom: '0.5rem' }}>{cert.title}</h3>
                      <p style={{ color: '#2563eb', fontWeight: '500' }}>{cert.provider}</p>
                    </div>
                    <span className="badge badge-outline">{cert.date}</span>
                  </div>
                  <p style={{ color: '#64748b', marginBottom: '1rem', lineHeight: '1.6' }}>{cert.description}</p>
                  <div>
                    <h4 style={{ fontWeight: '500', fontSize: '0.875rem', color: '#374151', marginBottom: '0.5rem' }}>
                      Skills Acquired:
                    </h4>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                      {cert.skills.map((skill) => (
                        <span key={skill} className="badge badge-secondary">
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Learning Philosophy */}
          <div className="card" style={{ background: 'linear-gradient(to right, #eff6ff, #f3e8ff)', border: 'none' }}>
            <div style={{ display: 'flex', alignItems: 'center', marginBottom: '1.5rem' }}>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#a855f7"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                style={{ marginRight: '0.75rem' }}
              >
                <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
                <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
              </svg>
              <h2 style={{ fontSize: '1.5rem' }}>Continuous Learning Philosophy</h2>
            </div>
            <p style={{ color: '#64748b', lineHeight: '1.7', fontSize: '1.125rem', marginBottom: '1.5rem' }}>
              I believe in the importance of continuous learning and staying updated with the latest technologies. My
              educational journey has provided me with a strong foundation in engineering principles, while my
              professional certifications have enhanced my practical skills in modern development tools and
              methodologies.
            </p>

            <div className="grid grid-3">
              <div style={{ textAlign: 'center' }}>
                <div style={{ 
                  width: '4rem', 
                  height: '4rem', 
                  backgroundColor: '#dbeafe', 
                  borderRadius: '50%', 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center', 
                  margin: '0 auto 0.75rem' 
                }}>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="32"
                    height="32"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="#2563eb"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M22 10v6M2 10l10-5 10 5-10 5z" />
                    <path d="M6 12v5c3 3 9 3 12 0v-5" />
                  </svg>
                </div>
                <h3 style={{ fontWeight: '600', marginBottom: '0.5rem' }}>Strong Foundation</h3>
                <p style={{ color: '#64748b', fontSize: '0.875rem' }}>Engineering principles and technical knowledge</p>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ 
                  width: '4rem', 
                  height: '4rem', 
                  backgroundColor: '#dcfce7', 
                  borderRadius: '50%', 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center', 
                  margin: '0 auto 0.75rem' 
                }}>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="32"
                    height="32"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="#22c55e"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M12 8a2 2 0 1 0 4 0 2 2 0 1 0-4 0" />
                    <path d="M12 2a6 6 0 0 1 6 6c0 1.5-1 6-6 10-5-4-6-8.5-6-10a6 6 0 0 1 6-6Z" />
                  </svg>
                </div>
                <h3 style={{ fontWeight: '600', marginBottom: '0.5rem' }}>Practical Skills</h3>
                <p style={{ color: '#64748b', fontSize: '0.875rem' }}>Industry-relevant certifications and training</p>
              </div>
              <div style={{ textAlign: 'center' }}>
                <div style={{ 
                  width: '4rem', 
                  height: '4rem', 
                  backgroundColor: '#f3e8ff', 
                  borderRadius: '50%', 
                  display: 'flex', 
                  alignItems: 'center', 
                  justifyContent: 'center', 
                  margin: '0 auto 0.75rem' 
                }}>
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="32"
                    height="32"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="#a855f7"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
                    <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
                  </svg>
                </div>
                <h3 style={{ fontWeight: '600', marginBottom: '0.5rem' }}>Continuous Growth</h3>
                <p style={{ color: '#64748b', fontSize: '0.875rem' }}>Always learning new technologies and methodologies</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
